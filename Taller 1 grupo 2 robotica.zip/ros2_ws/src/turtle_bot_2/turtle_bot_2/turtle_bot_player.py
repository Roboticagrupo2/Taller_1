#!/usr/bin/env python3

#----------------------------------------------#
#NODO TURTLE_BOT_PLAYER
#Nodo para reproducir secuencia de acciones en el Robot
#Taller #1 ROBÓTICA
#----------------------------------------------#

#LIBRERÍAS
import rclpy #libreria para nodos
from rclpy.node import Node #libreria para nodos
from geometry_msgs.msg import Twist #librería para mensaje Twist (vectores de posicion o velocidad)
import numpy as np #importa numpy para caclulos
import time #importa time para un temporizador
from functools import partial #importa partial para usarlo en recepcion del servicio
from my_robot_interfaces.srv import Nombre #Nombre es el servicio creado

class TurtleBotPlayer(Node): #definicion del nodo 

    def __init__(self): #función primaria
        super().__init__("turtle_bot_player") #nombre del nodo
        self.cmd_vel_pub = self.create_publisher(Twist, "/turtlebot_cmdVel",50) #se crea un publisher al tópico /turtlebot_cmdVel con mensaje Twist
        self.get_logger().info("Node turtle_bot_player created") #muestra mensaje en terminal de creacion exitosa del nodo 
        self.response_message = self.call_name_txt_service() #ejecuta la funcion call_name_txt_service(), donde se conecta al servicio                   
        
    def call_name_txt_service(self): #esta función se conecta al servicio y envía request
        client = self.create_client(Nombre,"txt_name") #se crea el cliente conectado al servicio Nombre
        while not client.wait_for_service(1.0): #si no encuentra el servicio,
            self.get_logger().warn("Waiting for Service") #muestra mensaje cada un segundo de esperando servicio
            
        request = Nombre.Request() #crea un mensaje de Request para el servicio Nombre
        request.a = "SolicitandoNombreDelArchivo" #crea un mensaje genérico
        future = client.call_async(request) #crea un future object que envia la reuest y recibe response
        future.add_done_callback(partial(self.callback_txt_name)) #en future se hace una callback a callback_txt_name

    def callback_txt_name(self, future): #recibe respuesta con el nombre del archivo
        try: #estructura try except en caso de que el servicio falle
            response=future.result() #recibe la rita de acceso como un string
            strin=str(response) #realiza una conversion explicita a string por si acaso
            extract=strin.split('name=') #por el formato del mensaje, la ruta de aceso se encuentra despues de name=
            extract=extract[1].split("'") #remueve las comillas de la ruta de acceso
            self.read_text_file(route=extract[1]) #extrae la ruta de aceso y la envia a la funcion read_text_file
        except Exception as e: #en caso de que el servicio falle
            self.get_logger().error("Service call failed: %r" % (e,)) #muestra error


    def read_text_file(self, route): #esta función lee un archivo de texto
        with open(route, "r") as file: #abre el acrhivo en la ruta de acceso
            lines = file.readlines() #obtiene todas las lineas del archivo
        self.info = np.array([0,0,0]) #crea un areglo de informacion donde van 3 cordenadas
        self.times = np.array([0]) #crea un areglo de tiempos
        for renglon in lines: #de todo el conjunto de lineas le renglon por renglon
            renglon=renglon.replace("[",",") #remplaza los corchetes por comas
            renglon=renglon.replace("]",",") #remplaza los corchetes por comas
            parts = renglon.split(',') #separa por comas
            new_row_time=[float(parts[1])] #el tiemp o se encontrará en el elemento con indice 1
            new_row_vel=[float(parts[2]),float(parts[3]),float(parts[4])] #las velocidades lineal x y, angular z se encuentran en los indices 2,3,4
            self.info=np.vstack([self.info, new_row_vel]) #añade al arreglo las velocidades
            self.times=np.vstack([self.times, new_row_time]) #añade al areglo los tiempos

        self.send_lines_of_txt() #llama función que envía lineas de texto

    def send_lines_of_txt(self): #esta función envía las linea del archivo de texto
        for i in range(1,len(self.info)): #recore todas las lineas de informacion
            #self.create_timer(0.15, self.send_velocity_command(data_vel=self.info[i]))
            self.send_velocity_command(data_vel=self.info[i]) #envia linea de infomracion a la funcion send_velocity_command
            if (i+1)<len(self.info): #si no ha legado al final
                #self.get_logger().info(str(float(self.times[i])))
                #self.get_logger().info(str(float(self.times[i+1])))
                time.sleep((float(self.times[i+1])-float(self.times[i]))*0.88) #espera el tiempo que se leyo entre dos comandos sucesivos    
            else: #si es la ultima linea
                time.sleep(0.15) #espera 0.15 segundos

    def send_velocity_command(self, data_vel): #esta funcion se encarga de enviar codigos al robot
        msg = Twist() #crea un mensaje tipo Twist
        msg.linear.x = data_vel[0] #el dato de velocidad lineal en x coresponde al dato 0 guardado
        msg.angular.z = data_vel[2] #del dato de velocidad angular en z coresponde al dadto 2 guardado
        self.cmd_vel_pub.publish(msg) #se publica el mensaje 
        self.get_logger().info(str(msg)) #escribe los mensajes en la terminal
 
    
def main(args=None): #main
    rclpy.init(args=args) #usado para ejecutar init del nodo
    node=TurtleBotPlayer() #crea el nodo
    rclpy.spin(node) #la función spin mantiene el nodo en ejecución
    rclpy.shutdown() #termina

if __name__ == '__main__':
    main()

