#!/usr/bin/env python3

#----------------------------------------------#
#NODO TURTLE_BOT_TELEOP
#Nodo para controlar el robot con flechas del teclado
#Taller #1 ROBÓTICA
#----------------------------------------------#

#LIBRERÍAS
import rclpy #libreria para nodos
from rclpy.node import Node #libreria para nodos
from geometry_msgs.msg import Twist #librería para mensaje Twist (vectores de posicion o velocidad)
from pynput import keyboard #libreria para utilizar el teclado
import time #libreria time para pausas o cronometros
from IPython.display import display, clear_output #libreria para mostrar pequeña interfaz
import tkinter as tk #libreria para mostrar pequeña interfaz
from tkinter import simpledialog #libreria para mostrar pequeña interfaz
from tkinter import filedialog #libreria para mostrar pequeña interfaz

class TurtleBotTeleop(Node): #definicion del nodo

    def __init__(self): #función primaria
        super().__init__("turtle_bot_teleop") #nombre del nodo
        self.cmd_vel_pub = self.create_publisher(Twist, "/turtlebot_cmdVel",50) #se crea un publisher al tópico /turtlebot_cmdVel con mensaje Twist
        self.timer_ = self.create_timer(0.25, self.send_velocity_command) #cada 0.25 segundos llama a la función send_velocity_command
        self.get_logger().info("Node turtle_bot_teleop created") #muestra mensaje en terminal de creacion exitosa del nodo 
        self.ask_for_parameters() #usa la funcion ask_for_parameter para que el usuario ingrese velocidad linear y angular
        #linear_speed = float(input("Ingrese la velocidad lineal: ")) #esta linea se encontraba antes de agregar la pequeña interfaz
        #angular_speed = float(input("Ingrese la velocidad angular: ")) #esta linea se encontraba antes de agregar la pequeña interfaz
        #self.linear_speed=linear_speed  #esta linea se encontraba antes de agregar la pequeña interfaz
        #self.angular_speed=angular_speed  #esta linea se encontraba antes de agregar la pequeña interfaz
        self.listen_to_keyboard() #usa la funcion listen_to_keyboard para captar teclas presionadas por el usuario
    
    def ask_for_parameters(self): #esta funcion se usa para pedir al usuario velocidad linear y angular
        self.root = tk.Tk() #creacion de ventana de tinker
        self.root.withdraw() #creacion de ventana de tinker
        linear_input = simpledialog.askfloat("Input", "Velocidad Lineal del robot:", parent=self.root) #pide una velocidad como float
        angular_input = simpledialog.askfloat("Input", "Velocidad Angular del robot:", parent=self.root) #pide una velocidad como float       
        if isinstance(linear_input, float)==False: #verifica que la entrada de usuario sea un float
            linear_input=1.5 #si no, da un valor por defecto para evitar errores
        if isinstance(angular_input, float)==False: #verifica que la entrada de usuario sea un float
            angular_input=2.0 #si no, da un valor por defecto para evitar errores
        self.linear_speed=linear_input #guarda la input como parámetro del nodo
        self.angular_speed=angular_input #guarda la input como parámetro del nodo

    def send_velocity_command(self, linear,angular): #este mensaje envia comandos al robot con velocidad linear y angular
        
        msg = Twist() #crea un mensaje tipo Twist
        msg.linear.x = linear #inserta el parámetro linear al mensaje
        msg.angular.z = angular #inserta el parámetro angular al mensaje
        self.cmd_vel_pub.publish(msg) #se publica el mensaje 
        self.get_logger().info(str(msg)) #escribe los mensajes en la terminal
    
    def listen_to_keyboard(self): #esta funcion se usa para escuchar las acciones del teclado
        # event listener
        with keyboard.Events() as events: #los eventos del teclado
            for event in events: #bucle "infinito"
                if event.key == keyboard.Key.esc: #si presiona tecla ESC se termina el ciclo y se deja de escuchar al teclado
                    break #rompe el ciclo
                else:
                    #print('Evento recibido {}'.format(event)) #descomentar esta linea para mostrar evento recibido en terminal
                    x=1 #variable auxiliar, se usa para revisar si no se está presionando nada en el teclado
                    if(str(event)=="Press(key=Key.up)"): #si presiona tecla hacia arriba
                        self.send_velocity_command(linear=self.linear_speed,angular=0.0) #envia velocidad linear positiva
                    elif(str(event)=="Press(key=Key.down)"): #si presiona tecla hacia abajo
                        self.send_velocity_command(linear=-self.linear_speed,angular=0.0) #envia velocidad linear negativa
                    elif(str(event)=="Press(key=Key.left)"): #si presiona tecla hacia izquierda
                        self.send_velocity_command(linear=0.0,angular=self.angular_speed) #envia velocidad angular positiva
                    elif(str(event)=="Press(key=Key.right)"): #si presiona tecla hacia derecha
                        self.send_velocity_command(linear=0.0,angular=-self.angular_speed) #envia velocidad angular negativa
                    elif(str(event)=="Release(key=Key.up)" or str(event)=="Release(key=Key.down)" or str(event)=="Release(key=Key.left)" or str(event)=="Release(key=Key.right)"):
                        #si libera una de las teclas 
                        self.send_velocity_command(linear=0.0,angular=0.0) #envía velocidad 0
                        while x==1: #se mantiene en ciclo
                            with keyboard.Events() as nuevos: 
                                nuevos = nuevos.get(0.15) #espera 0.15 segundos para recibir evento de tecla
                                if nuevos is None: #si no recibe ningún evento (no presiona tecla)
                                    self.send_velocity_command(linear=0.0,angular=0.0) #envía velocidad 0
                                else: #si recibe algún evento
                                    x=0 #sale del while
        
def main(args=None): #main
    rclpy.init(args=args) #usado para ejecutar init del nodo
    node=TurtleBotTeleop() #crea el nodo
    rclpy.spin(node) #la función spin mantiene el nodo en ejecución
    rclpy.shutdown() #termina

if __name__ == '__main__':
    main()

















